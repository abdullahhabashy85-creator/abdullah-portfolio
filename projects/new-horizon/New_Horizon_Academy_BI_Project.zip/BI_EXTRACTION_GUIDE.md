# ERP BI Extraction Guide

ERP = Source System.

Power BI:
ERP API -> Power Query -> Model -> DAX -> Dashboard

Use:
http://127.0.0.1:8000/docs
http://127.0.0.1:8000/api
http://127.0.0.1:8000/api/students
http://127.0.0.1:8000/api/attendance
http://127.0.0.1:8000/api/payments

SSIS:
LanguageInstituteERP SQL Database -> Staging -> Transform -> Data Warehouse -> SQL Analysis -> Power BI

Each student runs a local copy on their own PC.
