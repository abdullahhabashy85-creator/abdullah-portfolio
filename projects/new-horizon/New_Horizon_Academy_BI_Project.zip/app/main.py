from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import pyodbc

app = FastAPI(
    title="Language Institute ERP - BI Training Source",
    version="1.1",
    description="Classroom ERP source system for Power BI, SQL and SSIS training."
)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

CONN_STR = (
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost;"
    "DATABASE=LanguageInstituteERP;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)

USERS = {
    "admin": {"password": "admin123", "role": "Admin"},
    "manager": {"password": "manager123", "role": "Manager"},
    "teacher": {"password": "teacher123", "role": "Teacher"},
    "finance": {"password": "finance123", "role": "Finance"},
}

def get_connection():
    return pyodbc.connect(CONN_STR)

def fetch(sql, params=()):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(sql, params)
        if cur.description is None:
            return []
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]

def scalar(sql, params=()):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(sql, params)
        row = cur.fetchone()
        return 0 if row is None or row[0] is None else row[0]

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name="login.html", context={})

@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    username_clean = username.strip().lower()
    user = USERS.get(username_clean)
    if user and user["password"] == password:
        response = RedirectResponse("/dashboard", status_code=303)
        response.set_cookie(key="erp_user", value=username_clean, httponly=True)
        return response
    return RedirectResponse("/?error=1", status_code=303)

def current_user(request: Request):
    return request.cookies.get("erp_user")

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    username = current_user(request)
    if not username or username not in USERS:
        return RedirectResponse("/", status_code=303)
    cards = {
        "students": scalar("SELECT COUNT(*) FROM Students"),
        "batches": scalar("SELECT COUNT(*) FROM Batches"),
        "teachers": scalar("SELECT COUNT(*) FROM Teachers"),
        "branches": scalar("SELECT COUNT(*) FROM Branches"),
        "payments": scalar("SELECT COALESCE(SUM(Amount), 0) FROM Payments"),
        "attendance": scalar("SELECT CAST(100.0 * SUM(CASE WHEN AttendanceStatus='Present' THEN 1 ELSE 0 END) / NULLIF(COUNT(*),0) AS DECIMAL(5,1)) FROM Attendance"),
    }
    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={"user": username, "role": USERS[username]["role"], "cards": cards},
    )

@app.get("/logout")
def logout():
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("erp_user")
    return response

@app.get("/api")
def api_catalog():
    return {
        "purpose": "Classroom extraction API",
        "docs": "/docs",
        "openapi": "/openapi.json",
        "endpoints": [
            "/api/students", "/api/branches", "/api/teachers", "/api/levels",
            "/api/batches", "/api/batch-students", "/api/sessions",
            "/api/attendance", "/api/payments", "/api/exams",
            "/api/exam-results", "/api/placement-tests", "/api/summary"
        ]
    }

@app.get("/api/summary")
def api_summary():
    return {
        "students": scalar("SELECT COUNT(*) FROM Students"),
        "batches": scalar("SELECT COUNT(*) FROM Batches"),
        "teachers": scalar("SELECT COUNT(*) FROM Teachers"),
        "branches": scalar("SELECT COUNT(*) FROM Branches"),
        "payments_total": float(scalar("SELECT COALESCE(SUM(Amount),0) FROM Payments")),
        "attendance_present_rate": float(scalar("SELECT CAST(100.0 * SUM(CASE WHEN AttendanceStatus='Present' THEN 1 ELSE 0 END) / NULLIF(COUNT(*),0) AS DECIMAL(5,1)) FROM Attendance"))
    }

@app.get("/api/students")
def api_students():
    return fetch("SELECT TOP 100 * FROM Students ORDER BY StudentID")

@app.get("/api/branches")
def api_branches():
    return fetch("SELECT * FROM Branches ORDER BY BranchID")

@app.get("/api/teachers")
def api_teachers():
    return fetch("SELECT * FROM Teachers ORDER BY TeacherID")

@app.get("/api/levels")
def api_levels():
    return fetch("SELECT * FROM LanguageLevels ORDER BY LevelID")

@app.get("/api/batches")
def api_batches():
    return fetch("SELECT * FROM Batches ORDER BY BatchID")

@app.get("/api/batch-students")
def api_batch_students():
    return fetch("SELECT TOP 200 * FROM BatchStudents ORDER BY BatchStudentID")

@app.get("/api/sessions")
def api_sessions():
    return fetch("SELECT TOP 200 * FROM Sessions ORDER BY SessionID")

@app.get("/api/attendance")
def api_attendance():
    return fetch("SELECT TOP 500 * FROM Attendance ORDER BY AttendanceID")

@app.get("/api/payments")
def api_payments():
    return fetch("SELECT TOP 500 * FROM Payments ORDER BY PaymentID")

@app.get("/api/exams")
def api_exams():
    return fetch("SELECT * FROM Exams ORDER BY ExamID")

@app.get("/api/exam-results")
def api_exam_results():
    return fetch("SELECT TOP 500 * FROM ExamResults ORDER BY ExamResultID")

@app.get("/api/placement-tests")
def api_placement_tests():
    return fetch("SELECT TOP 500 * FROM PlacementTests ORDER BY PlacementTestID")

@app.get("/api/users-demo")
def api_users_demo():
    return JSONResponse({
        "note": "Demo classroom credentials",
        "users": [
            {"username": u, "password": d["password"], "role": d["role"]}
            for u, d in USERS.items()
        ]
    })
