# New Horizon Academy – End-to-End BI & Data Warehouse Solution

[![Power BI](https://img.shields.io/badge/Power_BI-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)](https://powerbi.microsoft.com/)
[![SQL Server](https://img.shields.io/badge/SQL_Server-CC292B?style=for-the-badge&logo=microsoftsqlserver&logoColor=white)](https://www.microsoft.com/sql-server)
[![SSIS](https://img.shields.io/badge/SSIS-0078D4?style=for-the-badge&logo=microsoft&logoColor=white)](https://learn.microsoft.com/en-us/sql/integration-services/)
[![FastAPI](https://img.shields.io/badge/FastAPI-009688?style=for-the-badge&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![Python](https://img.shields.io/badge/Python_3.8+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)

---

## 📌 Project Overview
**New Horizon Academy (Language Institute ERP - BI Track)** is an enterprise-grade, end-to-end Business Intelligence and Data Warehousing project. The solution bridges operational transactional systems (**OLTP**) and decision-support analytical systems (**OLAP**). 

The pipeline extracts raw data from an active educational ERP system running on **FastAPI**, orchestrates automated **SSIS ETL** workflows for data cleaning and surrogate key mapping, loads a clean **Star Schema Data Warehouse** hosted on **Microsoft SQL Server**, and delivers actionable executive insights via an interactive **Power BI** dashboard.

---

## 🏗 System Architecture & Data Flow

```
[Operational ERP (FastAPI + SQL/SQLite)]
               │
               ▼
   [SSIS Package: Control Flow]
   ├── 1. Truncate Staging Tables (Execute SQL Task)
   ├── 2. Extract Operational Tables to Staging (Data Flow Task)
   ├── 3. Load Conformed Dimensions with SKs (Data Flow Task)
   └── 4. Load Analytical Fact Tables with Lookups (Data Flow Task)
               │
               ▼
[SQL Server Data Warehouse (Star Schema)]
   ├── DimDate, DimBranch, DimStudent, DimTeacher, DimBatch, DimLevel
   └── FactPayment, FactAttendance, FactExamResult
               │
               ▼
[Power BI Executive Analytics Dashboard (DirectQuery / Import)]
   └── DAX Measures Table + Drill-through + Interactive Visuals
```

---

## 📊 Business Key Performance Indicators (KPIs)

- **Total Academy Revenue:** 11.50K EGP across all branches.
- **Overall Exam Pass Rate:** 80%.
- **Average Attendance Rate:** 71%.
- **Operational Scope:** 4 Branches (Nasr City, Alexandria, Maadi, October), 5 Enrolled Students, 3 Active Batches.
- **Curriculum Progression:** Monitored German language levels from A1 through C1.

---

## 🗄 Dimensional Data Warehouse Model (Star Schema)

The analytical data warehouse was engineered using dimensional modeling best practices to optimize query performance and eliminate analytical overhead on production databases:

### 🌟 Fact Tables
1. **`FactPayment`**:
   - Metrics: `AmountPaid`, `NetPaid`, `Discount`.
   - Keys: `PaymentSK`, `DateKey`, `BranchSK`, `StudentSK`.
2. **`FactAttendance`**:
   - Metrics: `IsPresent`, `DelayMinutes`.
   - Keys: `AttendanceSK`, `DateKey`, `BatchSK`, `TeacherSK`, `StudentSK`, `BranchSK`.
3. **`FactExamResult`**:
   - Metrics: `Score`, `Percentage`, `IsPass`.
   - Keys: `ExamResultSK`, `DateKey`, `BatchSK`, `LevelSK`, `StudentSK`.

### 🏛 Conformed Dimensions
- **`DimStudent`**: Student demographics, registration history, contact details.
- **`DimTeacher`**: Faculty profiles, specializations, hire dates.
- **`DimBranch`**: Campus locations (Alexandria, Maadi, Nasr City, 6th of October).
- **`DimBatch`**: Shift schedules, start/end timelines, batch capacities.
- **`DimLevel`**: Curriculum tracks (CEFR Levels: German A1, A2, B1, B2, C1).
- **`DimDate`**: Centralized fiscal and academic calendar dimension.

---

## ⚙️ ETL Pipeline Engineering (SSIS)

The ETL solution is developed inside `Package.dtsx` using **SQL Server Integration Services**:
- **Control Flow:** Sequential execution using Precedence Constraints starting with staging table truncation, moving to staging extraction, followed by dimensional loads, and concluding with fact table ingestion.
- **Data Conversion & Cleansing:** Handled data type conversions, null values imputation, and date parsing between source formats and SQL Server standards.
- **Lookup Transformations:** Implemented cached Lookups within Data Flows to dynamically resolve business keys into warehouse Surrogate Keys (`SK`) for all facts (`FactExamResult`, `FactAttendance`, `FactPayment`).

---

## 📈 Power BI Dashboard Highlights

- **Executive KPI Cards:** Real-time visibility into Revenue, Pass Rates, Active Students, and Average Attendance.
- **Revenue by Month & Branch:** Comparative matrix showcasing financial contribution across physical campuses.
- **Attendance vs. Absence by Batch:** Stacked bar charts isolating batches with attendance risks.
- **Score Progression by Language Level:** Academic difficulty curve tracking showing performance drops from beginner to advanced tiers.
- **Placement Test Distribution:** Demographic segmentation based on initial diagnostic assessments.

---

## 📁 Repository Structure

```
├── app/                              # FastAPI ERP Application Source
│   ├── main.py                       # FastAPI entrypoint & REST routing
│   └── ...                           # Database configuration & models
├── database/                         # Source database scripts & seeds
├── LanguageInstitute_ETL/            # SSIS Visual Studio Project
│   ├── Package.dtsx                  # Full ETL Control Flow & Data Flows
│   └── LanguageInstitute_ETL.dtproj  # Integration Services project config
├── SQLQuery1.sql                     # DDL scripts for Star Schema & Tables
├── New_Horizon_Dashboard.pbix        # Interactive Power BI Report File
├── requirements.txt                  # Python dependencies
└── README.md                         # Project documentation
```

---

## 🚀 How to Run Locally

### 1. Prerequisites
- Python 3.8+
- Microsoft SQL Server 2019+ & SQL Server Management Studio (SSMS)
- SQL Server Integration Services (SSIS) & Visual Studio with SSIS Extension
- Microsoft Power BI Desktop

### 2. Run Operational ERP (Source System)
```bash
# Navigate to project directory
cd LanguageInstituteERP_Local_v1

# Create and activate virtual environment
python -m venv .venv
.venv\Scripts\activate

# Install requirements
pip install -r requirements.txt

# Start ERP Uvicorn server
python -m uvicorn app.main:app --reload
```
Access the ERP portal at `http://127.0.0.1:8000/dashboard` and documentation at `http://127.0.0.1:8000/openapi.json`.

### 3. Deploy Data Warehouse & Run SSIS
1. Open SSMS and execute `SQLQuery1.sql` to generate staging and Star Schema tables in `LanguageInstituteDW`.
2. Open `LanguageInstitute_ETL.sln` in Visual Studio.
3. Configure the Connection Managers to point to your local SQL Server instance.
4. Execute `Package.dtsx` (Verify green checkmarks across Control Flow and Data Flows).

### 4. Open Power BI Dashboard
1. Open `New_Horizon_Dashboard.pbix` in Power BI Desktop.
2. Refresh data source connections if necessary to point to your local `LanguageInstituteDW`.

---

## 👨‍💻 Author
**Abdullah Habashy**  
*Data Analyst | BI Developer | SQL & Data Warehouse Specialist*  
- **Email:** [a.habashy.85@gmail.com](mailto:a.habashy.85@gmail.com)  
- **Phone:** 01030544862  
- **Portfolio:** [Abdullah Habashy Portfolio](https://abdullahhabashy85-creator.github.io/abdullah-portfolio/)
