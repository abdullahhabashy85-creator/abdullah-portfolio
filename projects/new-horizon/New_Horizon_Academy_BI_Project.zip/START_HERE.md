# Language Institute ERP Local v1

## Run
1. Install SQL Server Express + SSMS.
2. In SSMS run database/01_create_database.sql then 02_seed_data.sql.
3. Install Python 3.11+.
4. Open Terminal in this folder:
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
5. Start:
   uvicorn app.main:app --reload
6. Open http://127.0.0.1:8000

Demo accounts:
admin / admin123
manager / manager123
teacher / teacher123
finance / finance123

API docs:
http://127.0.0.1:8000/docs

If SQL Server is not localhost\SQLEXPRESS, edit CONN_STR in app/main.py.
