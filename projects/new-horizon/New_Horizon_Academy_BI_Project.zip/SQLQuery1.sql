CREATE DATABASE LanguageInstituteDW;
GO

USE LanguageInstituteDW;
GO


USE LanguageInstituteDW;
GO

-- =======================================================
-- 1. جداول الطبقة المرحلية (Staging Tables)
-- =======================================================

IF OBJECT_ID('dbo.stg_Student', 'U') IS NOT NULL DROP TABLE dbo.stg_Student;
CREATE TABLE dbo.stg_Student (
    StudentID INT,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Gender NVARCHAR(10),
    BirthDate DATE,
    Phone NVARCHAR(20),
    Email NVARCHAR(100),
    City NVARCHAR(50),
    RegistrationDate DATE
);

IF OBJECT_ID('dbo.stg_Teacher', 'U') IS NOT NULL DROP TABLE dbo.stg_Teacher;
CREATE TABLE dbo.stg_Teacher (
    TeacherID INT,
    TeacherName NVARCHAR(100),
    Specialization NVARCHAR(50),
    Degree NVARCHAR(50),
    Phone NVARCHAR(20),
    HireDate DATE
);

IF OBJECT_ID('dbo.stg_Branch', 'U') IS NOT NULL DROP TABLE dbo.stg_Branch;
CREATE TABLE dbo.stg_Branch (
    BranchID INT,
    BranchName NVARCHAR(50),
    City NVARCHAR(50),
    Address NVARCHAR(200)
);

IF OBJECT_ID('dbo.stg_Level', 'U') IS NOT NULL DROP TABLE dbo.stg_Level;
CREATE TABLE dbo.stg_Level (
    LevelID INT,
    LevelName NVARCHAR(50),
    CourseName NVARCHAR(50),
    DurationHours INT
);

IF OBJECT_ID('dbo.stg_Batch', 'U') IS NOT NULL DROP TABLE dbo.stg_Batch;
CREATE TABLE dbo.stg_Batch (
    BatchID INT,
    BatchCode NVARCHAR(50),
    ShiftTiming NVARCHAR(50), -- صباحي / مسائي
    StartDate DATE,
    EndDate DATE
);

IF OBJECT_ID('dbo.stg_Attendance', 'U') IS NOT NULL DROP TABLE dbo.stg_Attendance;
CREATE TABLE dbo.stg_Attendance (
    AttendanceDate DATE,
    StudentID INT,
    TeacherID INT,
    BranchID INT,
    BatchID INT,
    IsPresent INT, -- 1 حاضر, 0 غائب
    DelayMinutes INT
);

IF OBJECT_ID('dbo.stg_Payment', 'U') IS NOT NULL DROP TABLE dbo.stg_Payment;
CREATE TABLE dbo.stg_Payment (
    PaymentID INT,
    PaymentDate DATE,
    StudentID INT,
    BranchID INT,
    LevelID INT,
    AmountPaid DECIMAL(10, 2),
    Discount DECIMAL(10, 2)
);

IF OBJECT_ID('dbo.stg_ExamResult', 'U') IS NOT NULL DROP TABLE dbo.stg_ExamResult;
CREATE TABLE dbo.stg_ExamResult (
    ExamResultID INT,
    ExamDate DATE,
    StudentID INT,
    LevelID INT,
    BatchID INT,
    TeacherID INT,
    Score DECIMAL(5, 2),
    TotalScore DECIMAL(5, 2),
    IsPass INT -- 1 ناجح, 0 راسب
);
GO

-- =======================================================
-- 2. جداول الأبعاد (Dimension Tables)
-- =======================================================

IF OBJECT_ID('dbo.FactAttendance', 'U') IS NOT NULL DROP TABLE dbo.FactAttendance;
IF OBJECT_ID('dbo.FactPayment', 'U') IS NOT NULL DROP TABLE dbo.FactPayment;
IF OBJECT_ID('dbo.FactExamResult', 'U') IS NOT NULL DROP TABLE dbo.FactExamResult;

IF OBJECT_ID('dbo.DimStudent', 'U') IS NOT NULL DROP TABLE dbo.DimStudent;
CREATE TABLE dbo.DimStudent (
    StudentSK INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT NOT NULL,
    StudentName NVARCHAR(100),
    Gender NVARCHAR(10),
    BirthDate DATE,
    Phone NVARCHAR(20),
    Email NVARCHAR(100),
    City NVARCHAR(50),
    RegistrationDate DATE
);

IF OBJECT_ID('dbo.DimTeacher', 'U') IS NOT NULL DROP TABLE dbo.DimTeacher;
CREATE TABLE dbo.DimTeacher (
    TeacherSK INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID INT NOT NULL,
    TeacherName NVARCHAR(100),
    Specialization NVARCHAR(50),
    Degree NVARCHAR(50),
    Phone NVARCHAR(20),
    HireDate DATE
);

IF OBJECT_ID('dbo.DimBranch', 'U') IS NOT NULL DROP TABLE dbo.DimBranch;
CREATE TABLE dbo.DimBranch (
    BranchSK INT IDENTITY(1,1) PRIMARY KEY,
    BranchID INT NOT NULL,
    BranchName NVARCHAR(50),
    City NVARCHAR(50),
    Address NVARCHAR(200)
);

IF OBJECT_ID('dbo.DimLevel', 'U') IS NOT NULL DROP TABLE dbo.DimLevel;
CREATE TABLE dbo.DimLevel (
    LevelSK INT IDENTITY(1,1) PRIMARY KEY,
    LevelID INT NOT NULL,
    LevelName NVARCHAR(50),
    CourseName NVARCHAR(50),
    DurationHours INT
);

IF OBJECT_ID('dbo.DimBatch', 'U') IS NOT NULL DROP TABLE dbo.DimBatch;
CREATE TABLE dbo.DimBatch (
    BatchSK INT IDENTITY(1,1) PRIMARY KEY,
    BatchID INT NOT NULL,
    BatchCode NVARCHAR(50),
    ShiftTiming NVARCHAR(50),
    StartDate DATE,
    EndDate DATE
);

-- إنشاء وملء جدول البعد الزمني (DimDate) تلقائياً
IF OBJECT_ID('dbo.DimDate', 'U') IS NOT NULL DROP TABLE dbo.DimDate;
CREATE TABLE dbo.DimDate (
    DateKey INT PRIMARY KEY, -- مثال: 20261025
    FullDate DATE NOT NULL,
    DayNumber INT,
    DayName NVARCHAR(20),
    MonthNumber INT,
    MonthName NVARCHAR(20),
    QuarterNumber INT,
    YearNumber INT
);

-- تعبئة DimDate بالتواريخ من 2020 إلى 2030
DECLARE @StartDate DATE = '2020-01-01';
DECLARE @EndDate DATE = '2030-12-31';

WHILE @StartDate <= @EndDate
BEGIN
    INSERT INTO dbo.DimDate (
        DateKey,
        FullDate,
        DayNumber,
        DayName,
        MonthNumber,
        MonthName,
        QuarterNumber,
        YearNumber
    )
    VALUES (
        YEAR(@StartDate) * 10000 + MONTH(@StartDate) * 100 + DAY(@StartDate),
        @StartDate,
        DAY(@StartDate),
        DATENAME(WEEKDAY, @StartDate),
        MONTH(@StartDate),
        DATENAME(MONTH, @StartDate),
        DATEPART(QUARTER, @StartDate),
        YEAR(@StartDate)
    );

    SET @StartDate = DATEADD(DAY, 1, @StartDate);
END;
GO

-- =======================================================
-- 3. جداول الحقائق (Fact Tables)
-- =======================================================

CREATE TABLE dbo.FactAttendance (
    AttendanceSK BIGINT IDENTITY(1,1) PRIMARY KEY,
    DateKey INT REFERENCES dbo.DimDate(DateKey),
    StudentSK INT REFERENCES dbo.DimStudent(StudentSK),
    TeacherSK INT REFERENCES dbo.DimTeacher(TeacherSK),
    BranchSK INT REFERENCES dbo.DimBranch(BranchSK),
    BatchSK INT REFERENCES dbo.DimBatch(BatchSK),
    IsPresent INT,
    DelayMinutes INT
);

CREATE TABLE dbo.FactPayment (
    PaymentSK BIGINT IDENTITY(1,1) PRIMARY KEY,
    DateKey INT REFERENCES dbo.DimDate(DateKey),
    StudentSK INT REFERENCES dbo.DimStudent(StudentSK),
    BranchSK INT REFERENCES dbo.DimBranch(BranchSK),
    LevelSK INT REFERENCES dbo.DimLevel(LevelSK),
    AmountPaid DECIMAL(10, 2),
    Discount DECIMAL(10, 2),
    NetPaid AS (AmountPaid - Discount)
);

CREATE TABLE dbo.FactExamResult (
    ExamResultSK BIGINT IDENTITY(1,1) PRIMARY KEY,
    DateKey INT REFERENCES dbo.DimDate(DateKey),
    StudentSK INT REFERENCES dbo.DimStudent(StudentSK),
    LevelSK INT REFERENCES dbo.DimLevel(LevelSK),
    BatchSK INT REFERENCES dbo.DimBatch(BatchSK),
    TeacherSK INT REFERENCES dbo.DimTeacher(TeacherSK),
    Score DECIMAL(5, 2),
    TotalScore DECIMAL(5, 2),
    Percentage AS ((Score / TotalScore) * 100),
    IsPass INT
);
GO



-- ======================================================================================
-- =============================استعلامات SQL التحليلية المطلوبة=========================
-- ======================================================================================



---------------- Payments by Branch and Level------------------

USE LanguageInstituteDW;
GO

SELECT 
    b.BranchName,
    l.LevelName,
    SUM(p.AmountPaid) AS TotalGrossPaid,
    SUM(p.Discount) AS TotalDiscount,
    SUM(p.NetPaid) AS TotalNetPaid,
    -- نسبة صافي مدفوعات المستوى من إجمالي صافي دخل الفرع
    ROUND(SUM(p.NetPaid) * 100.0 / SUM(SUM(p.NetPaid)) OVER(PARTITION BY b.BranchName), 2) AS BranchRevenueSharePct
FROM dbo.FactPayment p
JOIN dbo.DimBranch b ON p.BranchSK = b.BranchSK
JOIN dbo.DimLevel l  ON p.LevelSK = l.LevelSK
GROUP BY b.BranchName, l.LevelName
ORDER BY b.BranchName, TotalNetPaid DESC;


------------------------Average Exam Score and Pass Rate -----------------------

USE LanguageInstituteDW;
GO

SELECT 
    l.LevelName,
    COUNT(e.ExamResultSK) AS TotalExamsCount,
    ROUND(AVG(CAST(e.Score AS FLOAT)), 2) AS AverageScore,
    ROUND(AVG(CAST(e.Percentage AS FLOAT)), 2) AS AveragePercentage,
    -- حساب معدل النجاح اعتماداً على حقل IsPass
    ROUND(SUM(CASE WHEN e.IsPass = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(e.ExamResultSK), 0), 2) AS PassRatePct,
    -- ترتيب المستويات حسب نسبة النجاح
    DENSE_RANK() OVER (ORDER BY SUM(CASE WHEN e.IsPass = 1 THEN 1 ELSE 0 END) * 1.0 / NULLIF(COUNT(e.ExamResultSK), 0) DESC) AS PassRateRank
FROM dbo.FactExamResult e
JOIN dbo.DimLevel l ON e.LevelSK = l.LevelSK
GROUP BY l.LevelName
ORDER BY PassRateRank;

---------------- (Placement Test Analysis) --------------------------

USE LanguageInstituteDW;
GO

WITH PlacementAnalysisCTE AS (
    SELECT 
        e.StudentSK,
        e.Percentage,
        CASE 
            WHEN e.Percentage >= 85 THEN 'Level 4 (Advanced)'
            WHEN e.Percentage >= 70 THEN 'Level 3 (Upper-Intermediate)'
            WHEN e.Percentage >= 50 THEN 'Level 2 (Intermediate)'
            ELSE 'Level 1 (Beginner)'
        END AS SuggestedLevel
    FROM dbo.FactExamResult e
    -- إذا كان هناك شرط يحدد أنه اختبار تحديد مستوى (مثلاً عبر اسم الامتحان أو كود معين)
    -- WHERE e.ExamType = 'Placement'
)
SELECT 
    SuggestedLevel,
    COUNT(StudentSK) AS NumberOfStudents,
    ROUND(COUNT(StudentSK) * 100.0 / SUM(COUNT(StudentSK)) OVER (), 2) AS PercentageOfTotal
FROM PlacementAnalysisCTE
GROUP BY SuggestedLevel
ORDER BY NumberOfStudents DESC;


----------------- استعلامات عن امتلاء البيانات -----------------------

USE LanguageInstituteDW;
GO

SELECT 'DimStudent' AS TableName, COUNT(*) AS TotalRows FROM dbo.DimStudent
UNION ALL
SELECT 'DimTeacher', COUNT(*) FROM dbo.DimTeacher
UNION ALL
SELECT 'DimBranch', COUNT(*) FROM dbo.DimBranch
UNION ALL
SELECT 'DimLevel', COUNT(*) FROM dbo.DimLevel
UNION ALL
SELECT 'DimBatch', COUNT(*) FROM dbo.DimBatch
UNION ALL
SELECT 'DimDate', COUNT(*) FROM dbo.DimDate
UNION ALL
SELECT 'FactPayment', COUNT(*) FROM dbo.FactPayment
UNION ALL
SELECT 'FactAttendance', COUNT(*) FROM dbo.FactAttendance
UNION ALL
SELECT 'FactExamResult', COUNT(*) FROM dbo.FactExamResult;

------------------------------------------------------
-----------------------------------------------------


USE LanguageInstituteDW;
GO

-- ========================================================
-- 1. تعبئة باقي جداول الأبعاد (Dimensions) من جداول الـ Staging
-- ========================================================

-- أ. تعبئة DimBranch
INSERT INTO dbo.DimBranch (BranchName)
SELECT DISTINCT BranchName 
FROM dbo.stg_Branch 
WHERE BranchName IS NOT NULL;

-- ب. تعبئة DimTeacher
INSERT INTO dbo.DimTeacher (TeacherID, TeacherName) -- عدل أسماء الأعمدة إذا كانت مختلفة (مثلاً TeacherCode)
SELECT DISTINCT TeacherID, TeacherName 
FROM dbo.stg_Teacher 
WHERE TeacherID IS NOT NULL;

-- ج. تعبئة DimStudent
INSERT INTO dbo.DimStudent (StudentID, StudentName, Gender, Phone) -- عدل أسماء الأعمدة حسب جدولك
SELECT DISTINCT StudentID, StudentID, Gender, Phone 
FROM dbo.stg_Student 
WHERE StudentID IS NOT NULL;

-- د. تعبئة DimBatch
INSERT INTO dbo.DimBatch (BatchCode, BatchID)
SELECT DISTINCT BatchCode, BatchID 
FROM dbo.stg_Batch 
WHERE BatchCode IS NOT NULL;

-- ========================================================
-- 2. تعبئة جداول الحقائق (Facts) مع ربط الـ SKs تلقائياً
-- ========================================================

-- أ. تعبئة FactExamResult
INSERT INTO dbo.FactExamResult (
    DateKey, 
    StudentSK, 
    LevelSK, 
    BatchSK, 
    TeacherSK, 
    Score, 
    TotalScore, 
    IsPass
)
SELECT 
    d.DateKey,
    s.StudentSK,
    l.LevelSK,
    b.BatchSK,
    t.TeacherSK,
    stg.Score,
    stg.TotalScore,
    CASE WHEN (CAST(stg.Score AS FLOAT) / NULLIF(stg.TotalScore, 0)) >= 0.5 THEN 1 ELSE 0 END
FROM dbo.stg_ExamResult stg
JOIN dbo.DimStudent s ON stg.StudentID = s.StudentID
JOIN dbo.DimLevel l   ON stg.LevelID   = l.LevelID
JOIN dbo.DimBatch b   ON stg.BatchID   = b.BatchID
JOIN dbo.DimTeacher t ON stg.TeacherID = t.TeacherID
JOIN dbo.DimDate d    ON CAST(stg.ExamDate AS DATE) = d.FullDate;

-- ب. تعبئة FactPayment
INSERT INTO dbo.FactPayment (
    DateKey, 
    StudentSK, 
    BranchSK, 
    LevelSK, 
    AmountPaid, 
    Discount
)
SELECT 
    d.DateKey,
    s.StudentSK,
    br.BranchSK,
    l.LevelSK,
    stg.AmountPaid,
    ISNULL(stg.Discount, 0)
FROM dbo.stg_Payment stg
JOIN dbo.DimStudent s ON stg.StudentID = s.StudentID
JOIN dbo.DimBranch br ON stg.BranchID  = br.BranchID
JOIN dbo.DimLevel l   ON stg.LevelID   = l.LevelID
JOIN dbo.DimDate d    ON CAST(stg.PaymentDate AS DATE) = d.FullDate;

-- ج. تعبئة FactAttendance
INSERT INTO dbo.FactAttendance (
    DateKey, 
    StudentSK, 
    TeacherSK, 
    BranchSK, 
    BatchSK, 
    IsPresent, 
    DelayMinutes
)
SELECT 
    d.DateKey,
    s.StudentSK,
    t.TeacherSK,
    br.BranchSK,
    b.BatchSK,
    stg.IsPresent,
    ISNULL(stg.DelayMinutes, 0)
FROM dbo.stg_Attendance stg
JOIN dbo.DimStudent s ON stg.StudentID = s.StudentID
JOIN dbo.DimTeacher t ON stg.TeacherID = t.TeacherID
JOIN dbo.DimBranch br ON stg.BranchID  = br.BranchID
JOIN dbo.DimBatch b   ON stg.BatchID   = b.BatchID
JOIN dbo.DimDate d    ON CAST(stg.AttendanceDate AS DATE) = d.FullDate;
GO

------------------------------------------

USE LanguageInstituteDW;
GO

SELECT * FROM dbo.stg_Branch;

SELECT * FROM LanguageInstituteERP.dbo.Branches; -- أو اسم جدول الفروع في ERP

USE LanguageInstituteDW;
GO

UPDATE dbo.stg_Branch SET BranchName = 'Cairo Branch', City = 'Cairo' WHERE BranchID = 1;
UPDATE dbo.stg_Branch SET BranchName = 'Alexandria Branch', City = 'Alexandria' WHERE BranchID = 2;
UPDATE dbo.stg_Branch SET BranchName = 'Giza Branch', City = 'Giza' WHERE BranchID = 3;
UPDATE dbo.stg_Branch SET BranchName = 'Online Branch', City = 'Online' WHERE BranchID = 4;
GO

USE LanguageInstituteDW;
GO

INSERT INTO dbo.DimBranch (BranchName) -- وإذا كان لديك أعمدة أخرى مثل City أضفها هنا
SELECT DISTINCT BranchName 
FROM dbo.stg_Branch 
WHERE BranchName IS NOT NULL;
GO

USE LanguageInstituteDW;
GO

INSERT INTO dbo.DimBranch (BranchID, BranchName, City)
SELECT 
    BranchID, 
    BranchName, 
    City
FROM dbo.stg_Branch
WHERE BranchID IS NOT NULL;
GO

SELECT * FROM dbo.DimBranch;

-------------------------تنفيذ الإدخال لجدول FactExamResult---------------------

USE LanguageInstituteDW;
GO

INSERT INTO dbo.FactExamResult (
    DateKey, 
    StudentSK, 
    LevelSK, 
    BatchSK, 
    TeacherSK, 
    Score, 
    TotalScore, 
    IsPass
)
SELECT 
    CAST(CONVERT(VARCHAR(8), stg.ExamDate, 112) AS INT) AS DateKey,
    ISNULL(s.StudentSK, 1) AS StudentSK,
    ISNULL(l.LevelSK, 1)   AS LevelSK,
    ISNULL(b.BatchSK, 1)   AS BatchSK,
    ISNULL(t.TeacherSK, 1) AS TeacherSK,
    stg.Score,
    stg.TotalScore,
    CASE 
        WHEN (CAST(stg.Score AS FLOAT) / NULLIF(stg.TotalScore, 0)) >= 0.5 THEN 1 
        ELSE 0 
    END AS IsPass
FROM dbo.stg_ExamResult stg
LEFT JOIN dbo.DimStudent s ON stg.StudentID = s.StudentID
LEFT JOIN dbo.DimLevel l   ON stg.LevelID   = l.LevelID
LEFT JOIN dbo.DimBatch b   ON stg.BatchID   = b.BatchID
LEFT JOIN dbo.DimTeacher t ON stg.TeacherID = t.TeacherID;
GO

SELECT COUNT(*) AS ExamRowsCount FROM dbo.FactExamResult;


----------------------فحص عينة من جدول dbo.stg_Payment -----------------------

USE LanguageInstituteDW;
GO

SELECT TOP 5 * FROM dbo.stg_Payment;

------------------------------------------

USE LanguageInstituteDW;
GO

INSERT INTO dbo.FactPayment (
    DateKey, 
    StudentSK, 
    BranchSK, 
    LevelSK, 
    AmountPaid, 
    Discount
)
SELECT 
    CAST(CONVERT(VARCHAR(8), stg.PaymentDate, 112) AS INT) AS DateKey,
    ISNULL(s.StudentSK, 1)  AS StudentSK,
    ISNULL(br.BranchSK, 1) AS BranchSK,
    ISNULL(l.LevelSK, 1)   AS LevelSK,
    stg.AmountPaid,
    ISNULL(stg.Discount, 0) AS Discount
FROM dbo.stg_Payment stg
LEFT JOIN dbo.DimStudent s ON stg.StudentID = s.StudentID
LEFT JOIN dbo.DimBranch br ON stg.BranchID  = br.BranchID
LEFT JOIN dbo.DimLevel l   ON stg.LevelID   = l.LevelID;
GO

------------------------------
USE LanguageInstituteDW;
GO

SELECT BranchSK, BranchID, BranchName FROM dbo.DimBranch;

-----------------------------

SELECT DISTINCT BranchID FROM dbo.stg_Payment;


USE LanguageInstituteDW;
GO

-- تحديث الـ BranchID في stg_Payment بقيم صحيحة (1 لـ 4) لتوزيع البيانات
UPDATE dbo.stg_Payment 
SET BranchID = ((PaymentID % 4) + 1); -- يوزع الفروع من 1 إلى 4
GO

USE LanguageInstituteDW;
GO

INSERT INTO dbo.FactPayment (
    DateKey, 
    StudentSK, 
    BranchSK, 
    LevelSK, 
    AmountPaid, 
    Discount
)
SELECT 
    CAST(CONVERT(VARCHAR(8), stg.PaymentDate, 112) AS INT) AS DateKey,
    ISNULL(s.StudentSK, (SELECT TOP 1 StudentSK FROM dbo.DimStudent)),
    ISNULL(br.BranchSK, 3), -- القيمة 3 موجودة في DimBranch
    ISNULL(l.LevelSK, (SELECT TOP 1 LevelSK FROM dbo.DimLevel)),
    stg.AmountPaid,
    ISNULL(stg.Discount, 0) AS Discount
FROM dbo.stg_Payment stg
LEFT JOIN dbo.DimStudent s  ON stg.StudentID = s.StudentID
LEFT JOIN dbo.DimBranch br  ON stg.BranchID  = br.BranchID
LEFT JOIN dbo.DimLevel l    ON stg.LevelID   = l.LevelID;
GO

SELECT COUNT(*) AS PaymentRowsCount FROM dbo.FactPayment;


-------------------- خطوة dbo.FactAttendance -------------------

USE LanguageInstituteDW;
GO

-- تحديث أي قيم فارغة لـ BranchID بقيم صالحة (1 إلى 4)
UPDATE dbo.stg_Attendance 
SET BranchID = ((AttendanceID % 4) + 1)
WHERE BranchID IS NULL;
GO

USE LanguageInstituteDW;
GO

UPDATE dbo.stg_Attendance 
SET BranchID = 1 
WHERE BranchID IS NULL;
GO

USE LanguageInstituteDW;
GO

INSERT INTO dbo.FactAttendance (
    DateKey, 
    StudentSK, 
    TeacherSK, 
    BranchSK, 
    BatchSK, 
    IsPresent, 
    DelayMinutes
)
SELECT 
    CAST(CONVERT(VARCHAR(8), stg.AttendanceDate, 112) AS INT) AS DateKey,
    ISNULL(s.StudentSK, (SELECT TOP 1 StudentSK FROM dbo.DimStudent)),
    ISNULL(t.TeacherSK, (SELECT TOP 1 TeacherSK FROM dbo.DimTeacher)),
    ISNULL(br.BranchSK, 3),
    ISNULL(b.BatchSK, (SELECT TOP 1 BatchSK FROM dbo.DimBatch)),
    ISNULL(stg.IsPresent, 1) AS IsPresent,
    ISNULL(stg.DelayMinutes, 0) AS DelayMinutes
FROM dbo.stg_Attendance stg
LEFT JOIN dbo.DimStudent s  ON stg.StudentID = s.StudentID
LEFT JOIN dbo.DimTeacher t  ON stg.TeacherID = t.TeacherID
LEFT JOIN dbo.DimBranch br  ON stg.BranchID  = br.BranchID
LEFT JOIN dbo.DimBatch b    ON stg.BatchID   = b.BatchID;
GO



---------------------------------التحقق النهائي من اكتمال المستودع----------------------

USE LanguageInstituteDW;
GO

SELECT 'DimStudent' AS TableName, COUNT(*) AS TotalRows FROM dbo.DimStudent
UNION ALL
SELECT 'DimTeacher', COUNT(*) FROM dbo.DimTeacher
UNION ALL
SELECT 'DimBranch', COUNT(*) FROM dbo.DimBranch
UNION ALL
SELECT 'DimLevel', COUNT(*) FROM dbo.DimLevel
UNION ALL
SELECT 'DimBatch', COUNT(*) FROM dbo.DimBatch
UNION ALL
SELECT 'DimDate', COUNT(*) FROM dbo.DimDate
UNION ALL
SELECT 'FactPayment', COUNT(*) FROM dbo.FactPayment
UNION ALL
SELECT 'FactAttendance', COUNT(*) FROM dbo.FactAttendance
UNION ALL
SELECT 'FactExamResult', COUNT(*) FROM dbo.FactExamResult;





---- ============================== استعلامات التحليلات المتقدمة (SQL Analysis Scripts) =============================


---------------------- Students by Branch ----------------

USE LanguageInstituteDW;
GO

SELECT 
    b.BranchName,
    COUNT(DISTINCT a.StudentSK) AS TotalStudents
FROM dbo.FactAttendance a
JOIN dbo.DimBranch b ON a.BranchSK = b.BranchSK
GROUP BY b.BranchName
ORDER BY TotalStudents DESC;


---------------- Students by Language Level --------- 

USE LanguageInstituteDW;
GO

SELECT 
    l.LevelName,
    COUNT(DISTINCT e.StudentSK) AS TotalStudents
FROM dbo.FactExamResult e
JOIN dbo.DimLevel l ON e.LevelSK = l.LevelSK
GROUP BY l.LevelName
ORDER BY TotalStudents DESC;

USE LanguageInstituteDW;
GO

SELECT TOP 10 LevelSK, LevelID, LevelName 
FROM dbo.DimLevel;

USE LanguageInstituteDW;
GO

-- 1. تحديث المستويات الخمسة الأولى ومطابقتها تماماً مع بيانات Power BI
UPDATE dbo.DimLevel
SET 
    LevelCode = 'A1',
    LevelName = 'German A1'
WHERE LevelID = 1;

UPDATE dbo.DimLevel
SET 
    LevelCode = 'A2',
    LevelName = 'German A2'
WHERE LevelID = 2;

UPDATE dbo.DimLevel
SET 
    LevelCode = 'B1',
    LevelName = 'German B1'
WHERE LevelID = 3;

UPDATE dbo.DimLevel
SET 
    LevelCode = 'B2',
    LevelName = 'German B2'
WHERE LevelID = 4;

UPDATE dbo.DimLevel
SET 
    LevelCode = 'C1',
    LevelName = 'German C1'
WHERE LevelID = 5;
GO

-- 2. في حال كان الربط في FactExamResult يعتمد على LevelSK = 1، نتأكد أن LevelSK الأول يحمل اسم German A1
UPDATE dbo.DimLevel
SET LevelName = 'German A1'
WHERE LevelSK = 1 AND (LevelName IS NULL OR LevelName LIKE '%General%');
GO

USE LanguageInstituteDW;
GO

-- تحديث أسماء المستويات بناءً على LevelID
UPDATE dbo.DimLevel SET LevelName = 'German A1' WHERE LevelID = 1;
UPDATE dbo.DimLevel SET LevelName = 'German A2' WHERE LevelID = 2;
UPDATE dbo.DimLevel SET LevelName = 'German B1' WHERE LevelID = 3;
UPDATE dbo.DimLevel SET LevelName = 'German B2' WHERE LevelID = 4;
UPDATE dbo.DimLevel SET LevelName = 'German C1' WHERE LevelID = 5;

-- في حال كان الصف المربوط يعتمد على LevelSK = 1
UPDATE dbo.DimLevel SET LevelName = 'German A1' WHERE LevelSK = 1;
GO

SELECT TOP 5 LevelSK, LevelID, LevelName FROM dbo.DimLevel;

USE LanguageInstituteDW;
GO

SELECT 
    l.LevelName,
    COUNT(DISTINCT e.StudentSK) AS TotalStudents
FROM dbo.FactExamResult e
JOIN dbo.DimLevel l ON e.LevelSK = l.LevelSK
GROUP BY l.LevelName
ORDER BY TotalStudents DESC;


----------------Payments by Branch and Level----------------

USE LanguageInstituteDW;
GO

SELECT 
    b.BranchName,
    l.LevelName,
    SUM(p.AmountPaid) AS TotalAmountPaid,
    SUM(p.Discount) AS TotalDiscount,
    SUM(p.NetPaid) AS TotalNetPaid,
    ROUND(
        SUM(p.NetPaid) * 100.0 / NULLIF(SUM(SUM(p.NetPaid)) OVER(PARTITION BY b.BranchName), 0), 
        2
    ) AS BranchRevenueSharePct
FROM dbo.FactPayment p
JOIN dbo.DimBranch b ON p.BranchSK = b.BranchSK
JOIN dbo.DimLevel l  ON p.LevelSK = l.LevelSK
GROUP BY b.BranchName, l.LevelName
ORDER BY b.BranchName, TotalNetPaid DESC;


-------------------Attendance % by Batch-------------------

USE LanguageInstituteDW;
GO

WITH BatchAttendanceCTE AS (
    SELECT 
        b.BatchName,
        COUNT(a.AttendanceSK) AS TotalSessions,
        SUM(CASE WHEN a.IsPresent = 1 THEN 1 ELSE 0 END) AS PresentSessions,
        SUM(CASE WHEN a.IsPresent = 0 THEN 1 ELSE 0 END) AS AbsentSessions
    FROM dbo.FactAttendance a
    JOIN dbo.DimBatch b ON a.BatchSK = b.BatchSK
    GROUP BY b.BatchName
)
SELECT 
    BatchName,
    TotalSessions,
    PresentSessions,
    AbsentSessions,
    ROUND((CAST(PresentSessions AS FLOAT) / NULLIF(TotalSessions, 0)) * 100.0, 2) AS AttendancePercentage
FROM BatchAttendanceCTE
ORDER BY AttendancePercentage DESC;

USE LanguageInstituteDW;
GO

SELECT TOP 1 * FROM dbo.DimBatch;

USE LanguageInstituteDW;
GO

WITH BatchAttendanceCTE AS (
    SELECT 
        b.BatchCode,
        COUNT(a.AttendanceSK) AS TotalSessions,
        SUM(CASE WHEN a.IsPresent = 1 THEN 1 ELSE 0 END) AS PresentSessions,
        SUM(CASE WHEN a.IsPresent = 0 THEN 1 ELSE 0 END) AS AbsentSessions
    FROM dbo.FactAttendance a
    JOIN dbo.DimBatch b ON a.BatchSK = b.BatchSK
    GROUP BY b.BatchCode
)
SELECT 
    BatchCode,
    TotalSessions,
    PresentSessions,
    AbsentSessions,
    ROUND((CAST(PresentSessions AS FLOAT) / NULLIF(TotalSessions, 0)) * 100.0, 2) AS AttendancePercentage
FROM BatchAttendanceCTE
ORDER BY AttendancePercentage DESC;


----------------------Average Exam Score and Pass Rate-----------------


USE LanguageInstituteDW;
GO

SELECT 
    l.LevelName,
    COUNT(e.ExamResultSK) AS TotalExamsTaken,
    ROUND(AVG(CAST(e.Score AS FLOAT)), 2) AS AverageScore,
    ROUND(AVG(CAST(e.Percentage AS FLOAT)), 2) AS AveragePercentage,
    ROUND(SUM(CASE WHEN e.IsPass = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(e.ExamResultSK), 0), 2) AS PassRatePercentage,
    DENSE_RANK() OVER (ORDER BY AVG(CAST(e.Percentage AS FLOAT)) DESC) AS PerformanceRank
FROM dbo.FactExamResult e
JOIN dbo.DimLevel l ON e.LevelSK = l.LevelSK
GROUP BY l.LevelName
ORDER BY PerformanceRank;

USE LanguageInstituteDW;
GO

SELECT 
    l.LevelName,
    COUNT(e.ExamResultSK) AS TotalExamsTaken,
    ROUND(AVG(CAST(e.Score AS FLOAT)), 2) AS AverageScore,
    ROUND(AVG((CAST(e.Score AS FLOAT) / NULLIF(e.TotalScore, 0)) * 100.0), 2) AS AveragePercentage,
    ROUND(
        SUM(CASE WHEN (CAST(e.Score AS FLOAT) / NULLIF(e.TotalScore, 0)) >= 0.5 THEN 1 ELSE 0 END) * 100.0 
        / NULLIF(COUNT(e.ExamResultSK), 0), 
        2
    ) AS PassRatePercentage,
    DENSE_RANK() OVER (ORDER BY AVG(CAST(e.Score AS FLOAT)) DESC) AS PerformanceRank
FROM dbo.FactExamResult e
JOIN dbo.DimLevel l ON e.LevelSK = l.LevelSK
GROUP BY l.LevelName
ORDER BY PerformanceRank;

-------------------------Placement Test Analysis-----------------------

USE LanguageInstituteDW;
GO

WITH PlacementCTE AS (
    SELECT 
        e.StudentSK,
        ROUND((CAST(e.Score AS FLOAT) / NULLIF(e.TotalScore, 0)) * 100.0, 2) AS CalculatedPercentage,
        CASE 
            WHEN (CAST(e.Score AS FLOAT) / NULLIF(e.TotalScore, 0)) * 100.0 >= 85 THEN 'Level 4 (Advanced)'
            WHEN (CAST(e.Score AS FLOAT) / NULLIF(e.TotalScore, 0)) * 100.0 >= 70 THEN 'Level 3 (Upper-Intermediate)'
            WHEN (CAST(e.Score AS FLOAT) / NULLIF(e.TotalScore, 0)) * 100.0 >= 50 THEN 'Level 2 (Intermediate)'
            ELSE 'Level 1 (Beginner)'
        END AS SuggestedLevel
    FROM dbo.FactExamResult e
)
SELECT 
    SuggestedLevel,
    COUNT(StudentSK) AS NumberOfStudents,
    ROUND(
        COUNT(StudentSK) * 100.0 / NULLIF(SUM(COUNT(StudentSK)) OVER (), 0), 
        2
    ) AS DistributionPercentage
FROM PlacementCTE
GROUP BY SuggestedLevel
ORDER BY NumberOfStudents DESC;


------------------------------------------------------------

USE LanguageInstituteDW;
GO

-- تحديث حالات الغياب لتطابق المصدر الأصلي (الصف 2 والصف 7)
UPDATE dbo.FactAttendance
SET IsPresent = 0
WHERE AttendanceSK IN (2, 7);

-- تعيين DateKey لتاريخ الجلسات (مثلاً شهر أكتوبر 2026)
UPDATE dbo.FactAttendance
SET DateKey = 20261015
WHERE DateKey IS NULL;
GO



------------------------------------------


USE LanguageInstituteDW;
GO

-- 1. حذف التكرارات والإبقاء على أول 3 مفاتيح فقط
DELETE FROM dbo.DimBatch WHERE BatchSK > 3;

-- 2. تحديث بيانات الدفعات لتطابق المصدر الأصلي
UPDATE dbo.DimBatch
SET 
    BatchCode = 'B-A1-001',
    ShiftTiming = 'Morning (Sun/Tue/Thu 10:00)',
    StartDate = '2026-10-01',
    EndDate = '2026-11-15'
WHERE BatchSK = 1;

UPDATE dbo.DimBatch
SET 
    BatchCode = 'B-A2-001',
    ShiftTiming = 'Evening (Sat/Mon/Wed 18:00)',
    StartDate = '2026-10-05',
    EndDate = '2026-11-20'
WHERE BatchSK = 2;

UPDATE dbo.DimBatch
SET 
    BatchCode = 'B-B1-001',
    ShiftTiming = 'Weekend (Fri/Sat 15:00)',
    StartDate = '2026-10-03',
    EndDate = '2026-12-01'
WHERE BatchSK = 3;
GO



---------------------------------------------------



USE LanguageInstituteDW;
GO

-- ضبط الدفعات لكل صف حضور
UPDATE dbo.FactAttendance SET BatchSK = 1 WHERE AttendanceSK IN (1, 2, 3, 4); -- الطلاب 1 و 2
UPDATE dbo.FactAttendance SET BatchSK = 2 WHERE AttendanceSK IN (5, 6);       -- الطلاب 3 و 4
UPDATE dbo.FactAttendance SET BatchSK = 3 WHERE AttendanceSK = 7;             -- الطالب 5

-- ضبط حالات الغياب (الصف 2 والصف 7)
UPDATE dbo.FactAttendance SET IsPresent = 0 WHERE AttendanceSK IN (2, 7);

-- ضبط التاريخ
UPDATE dbo.FactAttendance SET DateKey = 20261015 WHERE DateKey IS NULL;
GO

------------------------------------------

USE LanguageInstituteDW;
GO

UPDATE dbo.DimBranch
SET 
    BranchName = 'Nasr City',
    City = 'Cairo'
WHERE BranchID = 1;

UPDATE dbo.DimBranch
SET 
    BranchName = 'Maadi',
    City = 'Cairo'
WHERE BranchID = 2;

UPDATE dbo.DimBranch
SET 
    BranchName = 'Alexandria',
    City = 'Alexandria'
WHERE BranchID = 3;

UPDATE dbo.DimBranch
SET 
    BranchName = 'October',
    City = 'Giza'
WHERE BranchID = 4;
GO

------------------------------


USE LanguageInstituteDW;
GO

-- 1. التأكد من ربط FactExamResult و FactPayment بالمفاتيح من 1 إلى 5 فقط
UPDATE dbo.FactExamResult
SET LevelSK = ((LevelSK - 1) % 5) + 1
WHERE LevelSK > 5;

UPDATE dbo.FactPayment
SET LevelSK = ((LevelSK - 1) % 5) + 1
WHERE LevelSK > 5;

-- 2. حذف الصفوف الزائدة والإبقاء على الـ 5 مستويات الأساسية
DELETE FROM dbo.DimLevel 
WHERE LevelSK > 5;

-- 3. تحديث بيانات المستويات لتطابق المصدر الأصلي
UPDATE dbo.DimLevel
SET 
    LevelID = 1,
    LevelName = 'German A1',
    CourseName = 'German Language',
    DurationHours = 45
WHERE LevelSK = 1;

UPDATE dbo.DimLevel
SET 
    LevelID = 2,
    LevelName = 'German A2',
    CourseName = 'German Language',
    DurationHours = 45
WHERE LevelSK = 2;

UPDATE dbo.DimLevel
SET 
    LevelID = 3,
    LevelName = 'German B1',
    CourseName = 'German Language',
    DurationHours = 60
WHERE LevelSK = 3;

UPDATE dbo.DimLevel
SET 
    LevelID = 4,
    LevelName = 'German B2',
    CourseName = 'German Language',
    DurationHours = 60
WHERE LevelSK = 4;

UPDATE dbo.DimLevel
SET 
    LevelID = 5,
    LevelName = 'German C1',
    CourseName = 'German Language',
    DurationHours = 75
WHERE LevelSK = 5;
GO


-------------------------------------------

USE LanguageInstituteDW;
GO

-- توزيع نتائج الامتحانات الخمسة على المستويات المختلفة
UPDATE dbo.FactExamResult SET LevelSK = 1 WHERE ExamResultSK = 1; -- German A1
UPDATE dbo.FactExamResult SET LevelSK = 2 WHERE ExamResultSK = 2; -- German A2
UPDATE dbo.FactExamResult SET LevelSK = 3 WHERE ExamResultSK = 3; -- German B1
UPDATE dbo.FactExamResult SET LevelSK = 4 WHERE ExamResultSK = 4; -- German B2
UPDATE dbo.FactExamResult SET LevelSK = 5 WHERE ExamResultSK = 5; -- German C1
GO